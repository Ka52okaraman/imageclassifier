def check_command_line_arguments(in_arg):
    if in_arg is None:
        print("* Doesn't Check the Command Line Arguments because 'get_input_args' hasn't been defined.")
    else:
        # prints command line agrs
        print("Command Line Arguments:\n     dir_train =", in_arg.dir_train, 
              "\n     dir_valid =", in_arg.dir_valid, "\n  dir_test =", in_arg.dir_test, "\n  dir_flower =", in_arg.dir_flower)

