import torch
print(torch.__version__)
print(torch.cuda.is_available())
# Imports here


import matplotlib.pyplot as plt
from time import time, sleep
from torch import nn
from torch import optim
import torch.nn.functional as F
from torchvision import datasets, transforms, models
import time
import helper
import fc_model
import numpy as np
import pandas as pd
from get_input_args import get_input_args
import train, predict
from print_functions_for_lab_checks import *
import json
    
    
 

def main():
    in_arg = get_input_args()

    # Function that checks command line arguments using in_arg  
    check_command_line_arguments(in_arg)
    dataloaders_train, dataloaders_valid, dataloaders_test,image_datasets_data  = train.transform_image(in_arg.dir_train,in_arg.dir_valid,in_arg.dir_test)
   

    
    model = train.Classifier()

    images, labels = next(iter(dataloaders_test))

    #print(images.shape,labels.shape)
    # Get the class probabilities
    ps = torch.exp(model(images))
    print(ps.shape)
    
    train_losses, valid_losses, test_accuracy = train.training(dataloaders_train, dataloaders_valid, dataloaders_test, image_datasets_data )
    plt.plot(train_losses, label='Training loss')
    plt.plot(test_losses, label='Validation loss')
    plt.legend(frameon=False)
    model = train.load_checkpoint('model_D201.pth')
    print(model)
    
    im = predict.pre_procces_image(in_arg.dir_flower)
    im = predict.imshow(im)
    
   
    
    # TODO: Display an image along with the top 5 classes
    model.eval()


    plt.figure(figsize = (5,10))
    ax = plt.subplot(2,1,1)
    flower_num = in_arg.dir_flower.split('/')[-2]
    titel = "BLUMEN Zuordnung"
    im = pre_procces_img(im)
    imshow(im, ax, title = titel)
    
    top_prb, top_flwr, top_lbl = predict(in_arg.dir_flower, model) 
    plt.subplot(2,1,2)
    sns.barplot(x=prb, y=flowers, color=sns.color_palette()[0]);
    plt.show()
    
    
if __name__ == "__main__":
    main()