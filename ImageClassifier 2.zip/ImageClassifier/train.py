import torch
print(torch.__version__)
print(torch.cuda.is_available())
# Imports here
import matplotlib.pyplot as plt
from time import time, sleep
from torch import nn
from torch import optim
from torchvision import datasets, transforms, models
import torch.nn.functional as F
import numpy as np
# TODO: Define your transforms for the training, validation, and testing sets
def transform_image(train_dir, valid_dir, test_dir):
    data_transforms = transforms.Compose([transforms.RandomResizedCrop(256),
                                                transforms.RandomRotation(30),
                                                transforms.ColorJitter(),
                                                transforms.RandomHorizontalFlip(),
                                                transforms.CenterCrop(224), 
                                                transforms.ToTensor(),
                                                transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])

    train_transforms_validation =  transforms.Compose([transforms.Resize(256),
                                                     transforms.CenterCrop(224),
                                                     transforms.ToTensor(),
                                                     transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])


    test_transforms_test = transforms.Compose([transforms.Resize(256),
                                                     transforms.CenterCrop(224),
                                                     transforms.ToTensor(),
                                                     transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])

    # TODO: Load the datasets with ImageFolder
    image_datasets_data = datasets.ImageFolder(train_dir, transform=data_transforms)
    image_datasets_validation = datasets.ImageFolder(valid_dir, transform=train_transforms_validation)
    image_datasets_test = datasets.ImageFolder(test_dir, transform=test_transforms_test)
    
    dataloaders_train = torch.utils.data.DataLoader(image_datasets_data, batch_size=128, shuffle=True)
    dataloaders_valid = torch.utils.data.DataLoader(image_datasets_validation, batch_size=128, shuffle=True)
    dataloaders_test = torch.utils.data.DataLoader(image_datasets_test, batch_size=128,shuffle=False)
    
    return dataloaders_train, dataloaders_valid,dataloaders_test,image_datasets_data 

class Classifier(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(150528, 128)
        #self.fc1 = nn.Linear(3840, 1024)
        self.fc2 = nn.Linear(128, 102)
        #self.fc3 = nn.Linear(256, 102)
        #self.fc4 = nn.Linear(64, 10)

        # Dropout module with 0.2 drop probability
        self.dropout = nn.Dropout(p=0.2)

    def forward(self, x):
        # make sure input tensor is flattened
        #print("joooooodasdasdasdafaf:",x.shape)
        x = x.view(x.shape[0], -1)
        #print("joooooodasdasdasdafaf:",x.shape)
        # Now with dropout
        x = self.dropout(F.relu(self.fc1(x)))
        #x = self.dropout(F.relu(self.fc2(x)))
        #x = self.dropout(F.relu(self.fc3(x)))

        # output so no dropout here
        #x = F.log_softmax(self.fc4(x), dim=1)
        x = F.log_softmax(self.fc2(x), dim=1)
        #print("joooooodasdasdasdafaf:",x.shape)
        return x


def training(dataloaders_train, dataloaders_valid,dataloaders_test,image_datasets_data ):
    model = Classifier()# neu test
    criterion = nn.NLLLoss()
    optimizer = optim.Adam(model.parameters(), lr=0.001)
    start_time = time()
    epochs = 30
    steps = 0
    running_loss = 0
    valid_loss_min = np.Inf
    train_losses, valid_losses= [],[]
    for e in range(epochs):

        model.train()

        for images, labels in dataloaders_train:

            optimizer.zero_grad()

            log_ps = model(images)
            loss = criterion(log_ps, labels)
            loss.backward()
            optimizer.step()

            running_loss += loss.item()

        else:
            valid_loss = 0
            accuracy = 0

            # Turn off gradients for validation, saves memory and computations
            with torch.no_grad():
                model.eval()
                for images, labels in dataloaders_valid:
                    log_ps = model(images)
                    valid_loss += criterion(log_ps, labels)

                    ps = torch.exp(log_ps)
                    top_p, top_class = ps.topk(1, dim=1)
                    equals = top_class == labels.view(*top_class.shape)
                    accuracy += torch.mean(equals.type(torch.FloatTensor))

            model.train()

            train_losses.append(running_loss/len(dataloaders_train))
            valid_losses.append(valid_loss/len(dataloaders_valid))
            test_accuracy = accuracy/len(dataloaders_valid)
            print("Epoch: {}/{}.. ".format(e+1, epochs),
                  "Training Loss: {:.3f}.. ".format(running_loss/len(dataloaders_train)),
                  "Valid Loss: {:.3f}.. ".format(valid_loss/len(dataloaders_valid)),
                  "Test Accuracy: {:.3f}".format(test_accuracy))


            time_total = time() - start_time
            print('Training duration {:.0f}m {:.0f}s'.format(time_total // 60, time_total % 60))

            # Average validation loss
            valid_loss = valid_loss / len(dataloaders_valid)

            # If the validation loss is at a minimum
            if valid_loss < valid_loss_min:
                print('Validation loss decreased ({:.6f} ---> {:.6f}).  Save MODEL'.format(valid_loss_min,valid_loss))

                
                torch.save({
                            'epoch': epochs,                            
                            'state_dict':model.state_dict(),
                            'optimizer_state_dict':optimizer.state_dict(),
                            'loss': valid_loss,
                            'class_map': image_datasets_data.class_to_idx
                            },'model_D201.pth')

                valid_loss_min = valid_loss
    return train_losses, valid_losses, test_accuracy

def load_checkpoint(filepath):
    checkpoint = torch.load(filepath)
    
    model.load_state_dict(checkpoint['state_dict'])
    model.class_to_idx = checkpoint['class_map']
    return model
                
