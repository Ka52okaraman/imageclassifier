import argparse

def get_input_args():
    # Create Parse using ArgumentParser
    parser = argparse.ArgumentParser(description="classify images")
    # Create 3 command line arguments as mentioned above using add_argument() from ArguementParser method
    data_dir="flowers/"
    parser.add_argument("--dir_flowers",type=str, default=data_dir)
    parser.add_argument("--dir_train", type = str, default=data_dir+"/train")
    parser.add_argument("--dir_valid", type = str, default=data_dir+"/valid")
    parser.add_argument("--dir_test", type = str, default=data_dir+"/test")
    parser.add_argument("--dir_flower", type = str, default="flowers/test/1/image_06743.jpg")
    
    # Replace None with parser.parse_args() parsed argument collection that 
    # you created with this function 
    return parser.parse_args()