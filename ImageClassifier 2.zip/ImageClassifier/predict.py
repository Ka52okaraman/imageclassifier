    # TODO: Implement the code to predict the class from an image file
with open('cat_to_name.json', 'r') as f:
        cat_to_name = json.load(f)

def pre_procces_img(path_image):
    size = (1078,256)
    #allle Bilder laden test
    i=0
    for infile in glob.glob(path_image, recursive=True):#'flowers/**/*.jpg'
        file, ext = os.path.splitext(infile)
        with Image.open(infile) as im:
            print(im.show(),im.size)
            im.thumbnail(size)
            
            if im.size[1] < im.size[0]:
                im.thumbnail((256, 1000))
            else:
                im.thumbnail((1000, 256))
            
            print(im.show(),im.size)
            im.thumbnail(size)
            #print(im.show(),im.size)        
            #frac = 0.70
            #zu jpeg machen
            #left = im.size[0]*((1-frac)/2)
            #upper = im.size[1]*((1-frac)/2)
            #right = im.size[0]-((1-frac)/2)*im.size[0]
            #bottom = im.size[1]-((1-frac)/2)*im.size[1]
            #a=im.crop((left, upper, right, bottom))
            # zurecht schneiden
            im = ImageOps.fit(im, (224, 224), method=Image.BICUBIC, centering=(0.5, 0.5))
            #cropped_image.save("path_to_cropped_image.jpg")
            #print(cropped_image.show(),cropped_image.size)
            
            im = np.array(im)/255
            mean = np.array([0.485, 0.456, 0.406]) 
            std = np.array([0.229, 0.224, 0.225]) 
            im = (im - mean)/std
    
            
            im = im.transpose((2, 0, 1))           
            i+=1
            if i ==5:
                break
                
    return im

def imshow(image, ax=None, title=None):
    """Imshow for Tensor."""
    if ax is None:
        fig, ax = plt.subplots()
    
    # PyTorch tensors assume the color channel is the first dimension
    # but matplotlib assumes is the third dimension
    #image = image.numpy().transpose((1, 2, 0))
    image = image.transpose((1, 2, 0))
    
    # Undo preprocessing
    mean = np.array([0.485, 0.456, 0.406])
    std = np.array([0.229, 0.224, 0.225])
    image = std * image + mean
    
    # Image needs to be clipped between 0 and 1 or it looks like noise when displayed
    image = np.clip(image, 0, 1)
    
    ax.imshow(image)
    
    return ax
    
    
def predict(image_path, model, topk=5):
    ''' Predict the class (or classes) of an image using a trained deep learning model.
    '''  
    
    # TODO: Implement the code to predict the class from image file
    
    image = pre_procces_img(image_path)# hier das Bild vorbereiten
    image_tensor = torch.from_numpy(image).type(torch.FloatTensor)#transformiere zu tensor
    model_input = image_tensor.unsqueeze(0)# dem Bild ein batch hinzufügen
    #Wahrschinlichkeit berechnen
    prb = torch.exp(model.forward(model_input))#---------------ps = torch.exp(model(images) probs = torch.exp(model.forward(model_input))
    
    top_prb, top_labs = prb.topk(topk)
    top_prb = top_prb.detach().numpy().tolist()[0] 
    top_labs = top_labs.detach().numpy().tolist()[0]
    # mache indeces zu klassen
    idx_to_class = {val: key for key, val in model.class_to_idx.items()}# mit einer for schleife den
    #dictionary bauen
    top_lbl = [idx_to_class[lab] for lab in top_labs]# die labels in eine Liste hinzufügen
    top_flwr = [cat_to_name[idx_to_class[lab]] for lab in top_labs]# das selbe Prinzip
    
    return top_prb, top_flwr, top_lbl